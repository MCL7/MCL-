# -*- codeing = UTF-8 -*-
# @Time : 2021/4/23 13:09
# @Author : 苗春林
# @File : py_job_experience.py
# @Software : PyCharm

import matplotlib.pyplot as plt
import pandas as pd

# 解决中文显示问题
plt.rcParams['font.sans-serif'] = ['KaiTi']  # 指定默认字体
plt.rcParams['axes.unicode_minus'] = False  # 解决保存图像是负号'-'显示为方块的问题

# 读取excel数据
data = pd.read_excel("Lagou_python.xls", usecols=[4])
# 转化成列表
df_li = data.values.tolist()
# 空列表
results = []
# 将数据存储到空列表
for s_li in df_li:
    results.append(s_li[0])


# 统计相同项构造成词典
def all_list(arr):
    result = {}
    for i in set(arr):
        result[i] = arr.count(i)
    return result


# 标题
plt.title('工作经验分布占比图')

# 统计相同项构造成词典
all_lists = all_list(results)
# 饼图颜色
colors = ['red', 'yellowgreen', 'blue', 'lightskyblue', 'tomato', 'cornflowerblue']
# 饼图
plt.pie(all_lists.values(), autopct='%1.1f%%', labels=all_lists.keys(), colors=colors)
# 饼图标签
plt.legend(loc='upper right')
plt.axis('equal')
# 保存
plt.savefig("经验工作图.png")
# 展示
plt.show()
