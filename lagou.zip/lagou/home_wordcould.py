# -*- codeing = UTF-8 -*-
# @Time : 2021/5/15 22:17
# @Author : 苗春林
# @File : home_wordcould.py
# @Software : PyCharm

import pandas as pd
import matplotlib.pyplot as plt
from wordcloud import WordCloud# 词云展示库
from imageio import imread
import jieba  # 分词库
from pylab import mpl

# 使用matplotlib能够显示中文
mpl.rcParams['font.sans-serif'] = ['SimHei']  # 指定默认字体
mpl.rcParams['axes.unicode_minus'] = False  # 解决保存图像是负号'-'显示为方块的问题
#  读取数据
df = pd.read_csv('lagou_home.csv', encoding='gbk')

# 进行数据清洗，过滤掉实习岗位
df.drop(df[df['jobNature'].str.contains('实习')].index, inplace=True)
print(df.describe())

"""绘制招聘行业领域的词云"""
#
text = ''
for line in df['industryLables']:
    if len(eval(line)) == 0:
        continue
    else:
        for word in eval(line):
            print(word)
            text += word

cut_word = ','.join(jieba.cut(text))#以逗号进行分词
word_background = imread('词云.png')
cloud = WordCloud(
    #prefer_horizontal=0.9,#单词倾向于水平放置还是垂直放置，如果值小于1，则会在不合适的情况下旋转单词，浮点型，默认0.9
    font_path=r'C:\Windows\Fonts\simfang.ttf',
    background_color='white',  # 背景颜色
    mask=word_background,
    max_words=150,  # 最多显示词数
    max_font_size=100,  # 字体最大值
    scale=10,  # 清晰度
    relative_scaling=0.5,#单词出现频率对其字体大小的权重，值为0时，只考虑单词排名对字体大小的影响，值为1时，具有2倍出现频率的单词具有2倍的字体大小，一般值设置为0.5最棒，浮点型
)
word_cloud = cloud.generate(cut_word) #根据文本生成词云
plt.imshow(word_cloud)#显示图片
plt.axis('off')# 关闭坐标轴
plt.show()
word_cloud.to_file('招聘行业领域词云.png')# 保存结果图片