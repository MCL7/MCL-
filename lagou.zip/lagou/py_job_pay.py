# -*- codeing = UTF-8 -*-
# @Time : 2021/4/23 13:24
# @Author : 苗春林
# @File : py_job_pay.py
# @Software : PyCharm

# 条形图
# 导入绘图模块
import matplotlib.pyplot as plt
import pandas as pd

# 读取excel数据
data = pd.read_excel("Lagou_python.xls", usecols=[4, 2])
# 转化成列表
df_li = data.values.tolist()

# 构造工作经验词典
results = {
    "不限": [],
    "应届毕业生": [],
    "1年以下": [],
    "1-3年": [],
    "3-5年": [],
    "5-10年": [],
}

# 存储工作经验数据
for i in df_li:
    if i[1] == "3-5年":
        results["3-5年"].append(i[0])
    elif i[1] == "1-3年":
        results["1-3年"].append(i[0])
    elif i[1] == "5-10年":
        results["5-10年"].append(i[0])
    elif i[1] == "在校/应届":
        results["应届毕业生"].append(i[0])
    elif i[1] == "不限":
        results["不限"].append(i[0])
    elif i[1] == "1年以下":
        results["1年以下"].append(i[0])

# 计算平均薪资
for result in results:
    print(results[result])
    sum = 0
    for i in results[result]:
        str = i
        x = str.split("-")
        f = (int(x[0][:-1]) + int(x[1][:-1])) / 2
        sum = sum + f
        average = sum / (len(results[result]) + 1)
    results[result] = int(average * 1000)

# 解决中文显示问题
plt.rcParams['font.sans-serif'] = ['KaiTi']  # 指定默认字体
plt.rcParams['axes.unicode_minus'] = False  # 解决保存图像是负号'-'显示为方块的问题


# 构建数据
GDP = results.values()
print(GDP)
# 绘图
plt.bar(range(len(GDP)), GDP, align='center', color='blue', alpha=0.8)
# 添加轴标签
plt.ylabel('平均薪资')
# 添加标题
plt.title('工作经验-平均月薪分布图')
# 添加刻度标签
plt.xticks(range(len(GDP)), results.keys())
# 横轴旋转90度
#plt.xticks(rotation=90)

# 为每一个图形加数值标签
for x, y in enumerate(GDP):
    plt.text(x, y + 2, y, ha='center')
# 保存图像
plt.savefig('经验薪资图.png')
# 显示图形
plt.show()
