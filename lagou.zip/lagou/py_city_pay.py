# -*- codeing = UTF-8 -*-
# @Time : 2021/4/23 13:00
# @Author : 苗春林
# @File : py_city_pay.py
# @Software : PyCharm
# 条形图
# 导入绘图模块
import matplotlib.pyplot as plt
import pandas as pd

# 读取excel数据
data = pd.read_excel("Lagou_python.xls", usecols=[3, 2])
# 转化成列表
df_li = data.values.tolist()
# 空的键值列表
keys = []
# 创建键值列表
for i in df_li:
    if i[1] not in keys:
        keys.append(i[1])

# 创建空词典
results = {}
for key in keys:
    results.update({key: []})
print(results)

# 将数据存储到词典
for i in df_li:
    for key in keys:
        if i[1] == key:
            results[key].append(i[0])

print(results)

# 计算平均薪资
for result in results:
    print(results[result])
    sum = 0
    for i in results[result]:
        str = i
        x = str.split("-")#按字符’—‘进行分割
        f = (int(x[0][:-1]) + int(x[1][:-1])) / 2
        sum = sum + f
        average = sum / (len(results[result]) + 1)#len()计数
    results[result] = int(average * 1000)

print(results)

# 解决中文显示问题
plt.rcParams['font.sans-serif'] = ['KaiTi']  # 指定默认字体
plt.rcParams['axes.unicode_minus'] = False  # 解决保存图像是负号'-'显示为方块的问题

# 案例1：直辖市GDP水平
# 构建数据
GDP = results.values()
print(GDP)
sorted_x = sorted(results.items(), key=lambda item: item[1],reverse=True)
GDP1 = dict(sorted_x)
GDP2=GDP1.values()
# 绘图
plt.bar(range(len(GDP2)), GDP2, align='center', color='tomato', alpha=0.8)
# 添加轴标签
plt.ylabel('平均薪资')
# 添加标题
plt.title('城市-平均月薪分布图')
# 添加刻度标签
plt.xticks(range(len(GDP2)), GDP1.keys())
plt.xticks(rotation=90)

# 为每一个图形加数值标签
#for x, y in enumerate(GDP2):
#   plt.text(x, y + 2, y, ha='center')
# 保存图像
plt.savefig('城市薪资图.png')
# 显示图形
plt.show()
