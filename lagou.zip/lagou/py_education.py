# -*- codeing = UTF-8 -*-
# @Time : 2021/4/23 12:48
# @Author : 苗春林
# @File : py_education.py
# @Software : PyCharm

import matplotlib.pyplot as plt
import pandas as pd

# 解决中文显示问题
plt.rcParams['font.sans-serif'] = ['KaiTi']  # 指定默认字体
plt.rcParams['axes.unicode_minus'] = False  # 解决保存图像是负号'-'显示为方块的问题

# 读取excel数据
data = pd.read_excel("Lagou_python.xls", usecols=[5])
df_li = data.values.tolist()
results = []
for s_li in df_li:
    results.append(s_li[0])


def all_list(arr):
    result = {}
    for i in set(arr):
        result[i] = arr.count(i)
    return result


plt.title('学历要求占比图')

all_lists = all_list(results)
colors = ['red', 'yellowgreen', 'blue', 'lightskyblue', 'tomato', 'cornflowerblue']
plt.pie(all_lists.values(), autopct='%1.1f%%', labels=all_lists.keys(), colors=colors)
plt.legend(loc='upper right')
plt.axis('equal')
plt.savefig("学历要求占比图.png")
plt.show()
