# coding=utf-8
import pandas as pd
import matplotlib.pyplot as plt
from wordcloud import WordCloud  # 词云展示库
from imageio import imread
import jieba  # 分词库
from pylab import mpl

# 使用matplotlib能够显示中文
mpl.rcParams['font.sans-serif'] = ['SimHei']  # 指定默认字体
mpl.rcParams['axes.unicode_minus'] = False  # 解决保存图像是负号'-'显示为方块的问题
#  读取数据
df = pd.read_csv('py_csv_test.csv', encoding='gbk')
# 进行数据清洗，过滤掉实习岗位
# df.drop(df[df['职位名称'].str.contains('实习')].index, inplace=True)
# print(df.describe())

"""绘制词云"""
text = ''
for line in df['companyLabelList']:
    if len(eval(line)) == 0:
        continue
    else:
        for word in eval(line):
            # print(word)
            text += word
file_name={"带薪年假"}
jieba.load_userdict(file_name)
#exclude = {"年"}
cut_word = ','.join(jieba.cut(text))
word_background = imread('词云3.png')
cloud = WordCloud(
    font_path=r'C:\Windows\Fonts\simfang.ttf',
    background_color='white',  # 背景颜色
    mask=word_background,
    # prefer_horizontal=0.9,
    max_words=100,  # 最多显示词数
    max_font_size=100,  # 字体最大值
    scale=5,  # 清晰度
    #stopwords=exclude,
)
word_cloud = cloud.generate(cut_word)
plt.imshow(word_cloud)
plt.axis('off')  # 关闭坐标轴
plt.show()
word_cloud.to_file('公司福利.png')  # 保存结果图片
#
print(text)
