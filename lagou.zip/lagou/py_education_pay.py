# -*- codeing = UTF-8 -*-
# @Time : 2021/4/23 12:56
# @Author : 苗春林
# @File : py_education_pay.py
# @Software : PyCharm
# 条形图
# 导入绘图模块
import matplotlib.pyplot as plt
import pandas as pd

# 读取excel数据
data = pd.read_excel("lagou_python.xls", usecols=[5, 4, 2])
print(data)
# 转换成列表
df_li = data.values.tolist()
print(df_li)
# 创建学历词典
results = {
    "不限": [],
    "大专": [],
    "本科": [],
    "硕士": []
}
# 将数据存储到学历词典
for i in df_li:
    if i[2] == "不限" and i[1] == ("在校/应届" or "1年以下" or "1-3年"):
        results["不限"].append(i[0])
    elif i[2] == "大专" and i[1] == ("在校/应届" or "1年以下" or "1-3年"):
        results["大专"].append(i[0])
    elif i[2] == "本科" and i[1] == ("在校/应届" or "1年以下" or "1-3年"):
        results["本科"].append(i[0])
    elif i[2] == "硕士" and i[1] == ("在校/应届" or "1年以下" or "1-3年"):
        results["硕士"].append(i[0])

# 平均薪资
for result in results:
    print(results[result])
    sum = 0
    for i in results[result]:
        str = i
        x = str.split("-")
        f = (int(x[0][:-1]) + int(x[1][:-1])) / 2
        sum = sum + f
        average = sum / (len(results[result]) + 1)
    results[result] = int(average * 1000)

# 解决中文显示问题
plt.rcParams['font.sans-serif'] = ['KaiTi']  # 指定默认字体
plt.rcParams['axes.unicode_minus'] = False  # 解决保存图像是负号'-'显示为方块的问题

# 构建数据
GDP = results.values()
print(GDP)
print(results)
# 绘图
# plt.bar(range(len(GDP)), GDP, align='center', color='red', alpha=0.8)
plt.plot(range(len(GDP)),
         GDP,
         color='blue',
         linewidth=2,
         markersize=15,
         markeredgecolor='b',
         markerfacecolor='r'
         )
# 添加轴标签
plt.ylabel('平均薪资')
# 添加标题
plt.title('学历要求-平均月薪分布图')
# 添加刻度标签
plt.xticks(range(len(GDP)), results.keys())
# 横轴标签旋转90度
# plt.xticks(rotation=90)
# 为每一个图形加数值标签
for x, y in enumerate(GDP):
    plt.text(x, y + 2, y, ha='center')
# 保存图像
plt.savefig('学历薪资图.png')
# 显示图形
plt.show()
