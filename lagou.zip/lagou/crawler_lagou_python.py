# -*- coding = UTF-8 -*-
# @Time : 2021/4/22 10:42
# @Author : 苗春林
# @File : crawler_lagou_python.py
# @Software : PyCharm

# 导入库
import requests
import time
import json
import random
import xlwt  # 用于写入excel


def main():
    # 创建excel表
    workbook = xlwt.Workbook(encoding='utf-8')
    # 创建一个worksheet
    worksheet = workbook.add_sheet('My Worksheet')
    # 所有标题
    titles = ["公司名称", "职位名称", "薪资范围", "所在城市", "经验要求", "学历要求", "公司规模"]
    m = 0
    # 写入excel标题
    for y in range(len(titles)):
        worksheet.write(0, y, label=titles[y])
    # IP代理池
    proxies = [
        "117.93.118.88:3000",
        "175.43.32.19:9999",
        "117.65.14.145:9999",
        "114.103.169.9:9999",
        "123.169.124.4:9999"]
    proxies = {
        "http": str(random.sample(proxies, 1))
    }

    # 拉勾网主页
    url_start = "https://www.lagou.com/jobs/list_Python?city=%E6%88%90%E9%83%BD&cl=false&fromSearch=true&labelWords=&suginput="
    # 拉勾网Ajax:黏贴到网页上，开发者工具能找到
    url_parse = "https://www.lagou.com/jobs/positionAjax.json?city=全国&needAddtionalResult=false"
    # 添加头部
    headers = {
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Referer': 'https://www.lagou.com/jobs/list_%E8%BF%90%E7%BB%B4?city=%E6%88%90%E9%83%BD&cl=false&fromSearch=true&labelWords=&suginput=',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36',
        'cookie': 'user_trace_token=20210415113256-e63d3871-ae56-49e9-8cdf-41298f8ef400; _ga=GA1.2.2128790348.1618457578; LGUID=20210415113257-db95f40a-d916-4b81-ae17-486bb31fe148; RECOMMEND_TIP=true; index_location_city=%E5%85%A8%E5%9B%BD; showExpriedIndex=1; showExpriedCompanyHome=1; showExpriedMyPublish=1; hasDeliver=0; privacyPolicyPopup=false; __lg_stoken__=cb9112d153b917d5e932fe432d3d37c156da049cc0b27b78bd56a148a659cc561ff57e320383007d002eff202df47d70d36957652aa3b753f8304c3f1774520fd91d0db851f1; LGSID=20210521224250-97b0402a-77af-46de-859e-2544be55d8de; PRE_UTM=; PRE_HOST=; PRE_SITE=; PRE_LAND=https%3A%2F%2Fwww.lagou.com%2Fjobs%2Flist%5F%3FlabelWords%3D%26fromSearch%3Dtrue%26suginput%3D; _gid=GA1.2.1308180577.1621608170; JSESSIONID=ABAAAECABFAACEA5A1E6B0F62ACF28DF45EDE95B3A208D8; WEBTJ-ID=20210521%E4%B8%8B%E5%8D%8810:47:35224735-1798f655c395b6-06b77e93645c31-5771031-1327104-1798f655c3a93b; sensorsdata2015session=%7B%7D; _gat=1; Hm_lvt_4233e74dff0ae5bd0a3d81c6ccf756e6=1621436844,1621506529,1621608170,1621608456; SEARCH_ID=c70769088526491287f7d07d8a49e2ef; TG-TRACK-CODE=index_user; sm_auth_id=tmqjqahqrikkt8wp; gate_login_token=ceb9ed4120fd4d2e3617f00640639ef2a06649f69bc8fb940f8f282decc9c985; _putrc=2D5C5DEE9A58F461123F89F2B170EADC; login=true; unick=%E7%94%A8%E6%88%B73510; X_HTTP_TOKEN=992e6f044c05349a9948061261c4555cf3853afdf0; sensorsdata2015jssdkcross=%7B%22distinct_id%22%3A%2221410760%22%2C%22first_id%22%3A%2217914216f8b4b-0534e51222c53c-5771031-1327104-17914216f8cb1f%22%2C%22props%22%3A%7B%22%24latest_traffic_source_type%22%3A%22%E7%9B%B4%E6%8E%A5%E6%B5%81%E9%87%8F%22%2C%22%24latest_search_keyword%22%3A%22%E6%9C%AA%E5%8F%96%E5%88%B0%E5%80%BC_%E7%9B%B4%E6%8E%A5%E6%89%93%E5%BC%80%22%2C%22%24latest_referrer%22%3A%22%22%2C%22%24os%22%3A%22Windows%22%2C%22%24browser%22%3A%22Chrome%22%2C%22%24browser_version%22%3A%2289.0.4389.90%22%2C%22lagou_company_id%22%3A%22%22%7D%2C%22%24device_id%22%3A%2217914216f8b4b-0534e51222c53c-5771031-1327104-17914216f8cb1f%22%7D; LGRID=20210521224819-59fc740e-c544-46fb-b5b5-ac2b2794af6e; __SAFETY_CLOSE_TIME__21410760=1; Hm_lpvt_4233e74dff0ae5bd0a3d81c6ccf756e6=1621608499'
    }

    # 遍历Python职位30页信息
    for x in range(30):
        # 爬取信息参数
        data = {'first': 'true', 'pn': str(x), 'kd': 'Python'}
        s = requests.Session()
        # 请求首页获取cookies
        s.get(url_start, headers=headers, timeout=3)
        # 为此次获取的cookies
        cookie = s.cookies
        # 爬取信息
        response = s.post(url_parse, data=data, headers=headers, proxies=proxies, cookies=cookie, timeout=3)
        # 休息5ms
        time.sleep(5)
        response.encoding = response.apparent_encoding
        # 转化成json
        text = json.loads(response.text)
        # 获取json信息:开发者工具里面能够找到
        info = text["content"]["positionResult"]["result"]
        # 遍历json里的职位
        print(info)
        for w in range(len(info)):
            # 公司全称
            worksheet.write(m + 1, 0, label=info[w]["companyFullName"])
            # 职位全称
            worksheet.write(m + 1, 1, label=info[w]["positionName"])
            # 薪酬范围
            worksheet.write(m + 1, 2, label=info[w]["salary"])
            # 所在城市
            worksheet.write(m + 1, 3, label=info[w]["city"])
            # 工作经验
            worksheet.write(m + 1, 4, label=info[w]["workYear"])
            # 学历要求
            worksheet.write(m + 1, 5, label=info[w]["education"])
            # 公司规模
            worksheet.write(m + 1, 6, label=info[w]["companySize"])
            # excel计数
            m = m + 1

    # 保存excel
    workbook.save('Lagou_python11.xls')


if __name__ == '__main__':
    main()
