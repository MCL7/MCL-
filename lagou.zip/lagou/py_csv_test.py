# -*- codeing = UTF-8 -*-
# @Time : 2021/4/15 23:50
# @Author : 苗春林
# @File : py_csv_test.py
# @Software : PyCharm

# 导入库
import csv
import requests
import time
import json
import random
import jsonpath

# 设置UA池
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/22.0.1207.1 Safari/537.1",
    "Mozilla/5.0 (X11; CrOS i686 2268.111.0) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.57 Safari/536.11",
    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.1092.0 Safari/536.6",
    "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.1090.0 Safari/536.6",
    "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/19.77.34.5 Safari/537.1",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.9 Safari/536.5",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.6; rv:2.0.1) Gecko/20100101 Firefox/4.0.1"]


def main():
    # 创建一个csv文件，并将表头信息写入文件中
    with open('python_position.csv', 'w', encoding='utf-8') as csvfile:
        fieldnames = ['companyFullName', 'positionName', 'salary', 'city', 'workYear', 'education',
                      'companyLabelList', 'skillLables', 'companySize', 'jobNature']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

    # 设置IP代理池
    proxies = [
        "175.43.57.6:9999",
        "183.166.138.30:9999",
        "113.195.171.229:9999",
        "182.32.162.161:9999",
        "49.86.178.39:9999",
    ]
    proxies = {
        "http": str(random.sample(proxies, 1))
    }

    # 拉勾网主页
    url_start = "https://www.lagou.com/jobs/list_%E6%95%B0%E6%8D%AE%E5%88%86%E6%9E%90?labelWords=&fromSearch=true&suginput="
    # 拉勾网Ajax
    url_parse = "https://www.lagou.com/jobs/positionAjax.json?needAddtionalResult=false"
    # 添加头部
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Referer': 'https://www.lagou.com/jobs/list_%E6%95%B0%E6%8D%AE%E5%88%86%E6%9E%90?labelWords=&fromSearch=true&suginput=',
        'User-Agent': random.choice(USER_AGENTS),
        'cookie': 'user_trace_token=20210415113256-e63d3871-ae56-49e9-8cdf-41298f8ef400; _ga=GA1.2.2128790348.1618457578; LGUID=20210415113257-db95f40a-d916-4b81-ae17-486bb31fe148; RECOMMEND_TIP=true; index_location_city=%E5%85%A8%E5%9B%BD; showExpriedIndex=1; showExpriedCompanyHome=1; showExpriedMyPublish=1; hasDeliver=0; privacyPolicyPopup=false; _gid=GA1.2.2035803271.1619883052; __lg_stoken__=bc7422bc179279f60849a794f88ebb67ea2350af7ce12b79ed06e1a1119bdd6dcb163247555a76e115e11d6b2fc48eb6c740df0652a456d7b933256a6eb08200508a0d16e179; JSESSIONID=ABAAABAABAGABFAE9B18152866ED88AE5205FB883F47F3E; WEBTJ-ID=2021052%E4%B8%8B%E5%8D%887:32:42193242-1792cda1ef084-0a3cf507aaf547-5771031-1327104-1792cda1ef16e1; Hm_lvt_4233e74dff0ae5bd0a3d81c6ccf756e6=1619692484,1619883051,1619941069,1619955163; sensorsdata2015session=%7B%7D; TG-TRACK-CODE=index_user; PRE_UTM=; PRE_HOST=; PRE_LAND=https%3A%2F%2Fwww.lagou.com%2F; LGSID=20210502213954-b4236c31-7f97-4f20-8cf0-ef6b384f7129; PRE_SITE=https%3A%2F%2Fwww.lagou.com; gate_login_token=ceb9ed4120fd4d2e3617f00640639ef2a06649f69bc8fb940f8f282decc9c985; _putrc=2D5C5DEE9A58F461123F89F2B170EADC; login=true; unick=%E7%94%A8%E6%88%B73510; _gat=1; X_MIDDLE_TOKEN=abb530d7756ec7db8ca41cfdb92fa843; X_HTTP_TOKEN=992e6f044c05349a1233699161c4555cf3853afdf0; sensorsdata2015jssdkcross=%7B%22distinct_id%22%3A%2221410760%22%2C%22first_id%22%3A%2217914216f8b4b-0534e51222c53c-5771031-1327104-17914216f8cb1f%22%2C%22props%22%3A%7B%22%24latest_traffic_source_type%22%3A%22%E7%9B%B4%E6%8E%A5%E6%B5%81%E9%87%8F%22%2C%22%24latest_search_keyword%22%3A%22%E6%9C%AA%E5%8F%96%E5%88%B0%E5%80%BC_%E7%9B%B4%E6%8E%A5%E6%89%93%E5%BC%80%22%2C%22%24latest_referrer%22%3A%22%22%2C%22%24os%22%3A%22Windows%22%2C%22%24browser%22%3A%22Chrome%22%2C%22%24browser_version%22%3A%2289.0.4389.90%22%2C%22lagou_company_id%22%3A%22%22%7D%2C%22%24device_id%22%3A%2217914216f8b4b-0534e51222c53c-5771031-1327104-17914216f8cb1f%22%7D; Hm_lpvt_4233e74dff0ae5bd0a3d81c6ccf756e6=1619963321; LGRID=20210502214841-10172dd7-3ee6-4c56-a301-058e824b8a37; SEARCH_ID=ed8a1a00e63149ee80d0adbd75e4be43'
    }

    # 遍历Python职位30页信息
    for x in range(30):
        # 爬取信息参数
        data = {'first': 'true',
                'pn': str(x),
                'kd': 'python'}

        s = requests.Session()
        # 请求首页获取cookies
        s.get(url_start, headers=headers, timeout=3)
        # 为此次获取的cookies
        cookie = s.cookies
        # 爬取信息
        response = s.post(url_parse, data=data, headers=headers, proxies=proxies, cookies=cookie, timeout=3)
        # 休息5ms
        time.sleep(5)
        response.encoding = response.apparent_encoding
        # 转化成json
        text = json.loads(response.text)
        # 获取json信息:开发者工具里面能够找到
        # info = text["content"]["positionResult"]["result"]
        info = jsonpath.jsonpath(text, '$..result')[0]
        # 遍历json里的职位
        # print(info)
        for result in info:  # 获取每条数据并以字典类型存储
            infos = {
                'companyFullName': result['companyFullName'],
                'positionName': result['positionName'],
                'salary': result['salary'],
                'city': result['city'],
                'workYear': result['workYear'],
                'education': result['education'],
                'companyLabelList': result['companyLabelList'],
                'skillLables': result['skillLables'],
                'companySize': result['companySize'],
                'jobNature': result['jobNature'],
            }
            print('-------------')
            print(infos)
            # 保存csv
            with open('python_position.csv', 'a', newline='') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writerow(infos)
        time.sleep(5)
    csvfile.close()


if __name__ == '__main__':
    main()
