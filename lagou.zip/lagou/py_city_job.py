# -*- codeing = UTF-8 -*-
# @Time : 2021/4/23 12:58
# @Author : 苗春林
# @File : py_city_job.py
# @Software : PyCharm

# 条形图
# 导入绘图模块
import matplotlib.pyplot as plt
import pandas as pd

# 读取excel数据
data = pd.read_excel("Lagou_python.xls", usecols=[3])
# 转化成列表
df_li = data.values.tolist()
# 空列表
results = []

# 列表中提取数据到results
for s_li in df_li:
    results.append(s_li[0])  # 补增到s_li中


# 统计列表中相同项的个数组成词典
def all_list(arr):
    result = {}
    for i in set(arr):
        result[i] = arr.count(i)
    return result


# 统计列表中相同项的个数组成词典
all_lists = all_list(results)

# 解决中文显示问题
plt.rcParams['font.sans-serif'] = ['KaiTi']  # 指定默认字体
plt.rcParams['axes.unicode_minus'] = False  # 解决保存图像是负号'-'显示为方块的问题

# 构建数据
NUM = all_lists.values()
print(NUM)
print(all_lists)
sorted_x = sorted(all_lists.items(), key=lambda item: item[1], reverse=True)  # 降序排序根据值排序，转为元组

NUM1 = dict(sorted_x)
NUM2 = NUM1.values()
print(NUM1)
# 绘图柱状图
plt.bar(range(len(NUM2)), NUM2, align='center', color='steelblue', alpha=0.8)
# 添加轴标签
plt.ylabel('职位数')
# 添加标题
plt.title('城市职位数分布图')
# 添加刻度标签
plt.xticks(range(len(NUM2)), NUM1.keys())
# 横轴标签转换90度
plt.xticks(rotation=90)
# 为每一个图形加数值标签
for x, y in enumerate(NUM2):
    plt.text(x, y + 2, y, ha='center')
# 保存图像
plt.savefig('城市职位数分布图.png')
# 显示图形
plt.show()
